function cartPage(id) {
    window.location.href = `/product/${id}`;
};

